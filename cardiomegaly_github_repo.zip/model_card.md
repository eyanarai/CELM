---
language: en
license: mit
tags:
  - chest-xray
  - cardiomegaly
  - medical-imaging
  - ensemble-learning
---

# Cardiomegaly Classification with CELM

This model ensemble (VGG16 + ResNet50 + InceptionV3 + meta-learner) is trained to detect cardiomegaly using CXR datasets (CheXpert, NIH, PadChest, VinDr). The preprocessing pipeline includes CLAHE, denoising, and augmentation.

## Intended Use
Medical decision support tool for research purposes.

## Training
Models were trained on a curated dataset of 46,000+ labeled CXR images using TensorFlow/Keras and logistic regression for stacking ensemble.

## Metrics
F1-score: 0.97, Accuracy: 97.8%, Precision: 98.4%, Recall: 97.4%
