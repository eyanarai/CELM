# Cardiomegaly CXR Classification Dataset

This repository contains curated and preprocessed subsets from four major chest X-ray datasets (CheXpert, NIH CXR, PadChest, VinDr) for binary classification of cardiomegaly (enlarged heart) vs. non-cardiomegaly cases.

## Contents

- `chexpert_subset.csv` – 23,002 cardiomegaly and 7,869 normal frontal CXRs from CheXpert
- `nih_subset.csv` – Balanced 1,563 cardiomegaly and 1,563 normal samples from NIH ChestX-ray14
- `padchest_subset.csv` – 2,140 cardiomegaly and 8,708 normal samples from PadChest
- `vindr_subset.csv` – 230 cardiomegaly and 1,003 normal samples from VinDr-CXR
- `combined_dataset.csv` – All datasets combined into a unified file with 46,078 samples

## Columns

Each file contains the following columns:
- `image_id`: The filename or ID of the image
- `label`: Binary label (1 = cardiomegaly, 0 = normal)
- `dataset`: Source of the sample (CheXpert, NIH_CXR, PadChest, VinDr)

## Usage

You can use these files with your own image directory structure or with the Colab notebook included in the paper repository.

## Citation

If you use these subsets, please cite the originating datasets and the associated publication.

